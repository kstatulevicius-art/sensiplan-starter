// Next.js TypeScript declarations
/// <reference types="next" />
/// <reference types="next/image-types/global" />
